export const theme = {
  headerFont: "'Luckiest Guy', cursive",
  mainFont: "'Open Sans', sans-serif",
  primaryDark: '#3D405B',
  secondaryDark: '#000000',
  primaryLight: '#F4F1DE',
  secondaryLight: '#F2CC8F',
  primaryAccent: '#E07A5F',
  secondaryAccent: '#81B29A',
}