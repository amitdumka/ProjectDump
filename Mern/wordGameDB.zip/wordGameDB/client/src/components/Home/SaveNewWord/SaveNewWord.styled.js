import styled from 'styled-components';

export const StyledSaveNewWord = styled.section`
  padding: 20px 0px;
`;