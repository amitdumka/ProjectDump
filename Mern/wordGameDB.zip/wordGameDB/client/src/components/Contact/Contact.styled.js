import styled from 'styled-components';

export const StyledContact = styled.div`
  p {
    span {
      text-decoration: underline;
    }
  }
  button {
    margin-bottom: 50px;
  }
`;